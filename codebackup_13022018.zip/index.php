<?php

require_once("inc/config.inc.php");
require_once("inc/functions.inc.php");
include("login.php");
